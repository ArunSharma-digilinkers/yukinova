@extends('layouts.main')
@section('content')

<div class="main-wrapper">

</div>

@endsection