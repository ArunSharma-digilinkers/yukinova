@extends('layouts.admin')

@section('title', 'Dashboard')

@section('content')



@endsection