<header>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm">
        <div class="container-fluid">

            <!-- Logo -->
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo" class="img-fluid logo-img" width="150">
            </a>

            <!-- Mobile Toggle -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar Content -->
            <div class="collapse navbar-collapse" id="navbarNav">

                <ul class="navbar-nav ms-auto align-items-lg-center">

                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(url('/')); ?>">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('about-us')); ?>">About Us</a>
                    </li>

                    <!-- Products Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            Products
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(url('hybrid-inverter')); ?>">Hybrid Inverter</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('inverter-battery')); ?>">Inverter Battery</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('three-wheeler-battery')); ?>">Three Wheeler Battery</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('two-wheeler-battery')); ?>">Two Wheeler Battery</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('cycle-battery')); ?>">Cycle Battery</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('portable-power-solution')); ?>">Portable Power Solution</a></li>
                        </ul>
                    </li>

                    <!-- Industry Dropdown -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            Industry Serve
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Automotive Battery</a></li>
                        </ul>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="#">Blog</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('contact-us')); ?>">Contact Us</a>
                    </li>

                    <!-- CART ICON -->
                    <li class="nav-item position-relative ms-lg-3">
                        <a class="nav-link" href="#">
                            <i class="fa-solid fa-cart-shopping"></i>
                            <span class="cart-count">
                                <?php echo e(session('cart') ? count(session('cart')) : 0); ?>

                            </span>
                        </a>
                    </li>
                    

                    <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item ms-lg-2">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">
                            <i class="fa-regular fa-user"></i> Login
                        </a>
                    </li>

                    <li class="nav-item ms-lg-2">
                        <a class="nav-link btn-register" href="<?php echo e(route('register')); ?>">
                            Register
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown"
                            role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="<?php echo e(auth()->user()->avatar_url ?? asset('img/default-avatar.png')); ?>"
                                class="rounded-circle me-1" style="width: 24px; height: 24px; object-fit: cover;">
                            <?php echo e(auth()->user()->name); ?>

                        </a>

                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">
                                    <i class="fas fa-tachometer-alt me-2"></i>Admin Panel
                                </a>
                            </li>
                            <?php else: ?>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('user.dashboard')); ?>">
                                    <i class="fas fa-box me-2"></i>My Orders
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('user.addresses.index')); ?>">
                                    <i class="fas fa-map-marker-alt me-2"></i>Addresses
                                </a>
                            </li>
                            <?php endif; ?>

                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                                    <i class="fas fa-user-edit me-2"></i>Profile
                                </a>
                            </li>

                            <li>
                                <hr class="dropdown-divider">
                            </li>

                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">
                                        <i class="fas fa-sign-out-alt me-2"></i>Logout
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>

                </ul>

            </div>
        </div>
    </nav>
</header><?php /**PATH C:\xampp\htdocs\yukinova\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>